<?php
session_start();
session_destroy(); // Hủy session
header("Location: MVC/view/login.php"); // Chuyển hướng về trang login
exit();
?>
