<?php
session_start();
require_once "./MVC/controller/UserController.php";
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$userController = new UserController();

if (isset($_GET['action'])) {
    $action = $_GET['action'];
    // Xử lý yêu cầu đăng nhập
    if ($action == 'login' && $_SERVER['REQUEST_METHOD'] == 'POST') {
        $username = $_POST['username']; // Lấy tên người dùng
        $password = $_POST['password']; // Lấy mật khẩu
        
        // Gọi hàm đăng nhập từ UserController
        $userController->login($username, $password);
    } 

    if ($action == 'register' && $_SERVER['REQUEST_METHOD'] == 'POST') {
        $username = $_POST['username'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $password_confirm = $_POST['password_confirm'];
        
        $userController->register($username, $email, $password, $password_confirm);
    }
} else {
    include './MVC/view/login.php';
}

?>
