<?php
require_once "../model/Database.php";

class RoomModel {
    private $conn;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->conn;
    }

    public function getRoomById($id) {
        $stmt = $this->conn->prepare("SELECT * FROM ROOM WHERE ID = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        return $result->fetch_assoc(); // Trả về thông tin phòng
    }

    public function __destruct() {
        $this->conn->close();
    }
}
?>
