<?php
require_once "./MVC/model/Database.php";

class UserModel {
    private $conn;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->conn;
    }

    public function register($username, $email, $password, $confirmpass) {
        $stmt = $this->conn->prepare("INSERT INTO USER (username, email, password, confirmpass) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $username, $email, $password, $confirmpass);

        if ($stmt->execute()) {
            return true;
        } else {
            echo "Error: " . $this->conn->error;
            return false;
        }
    }

    public function __destruct() {
        $this->conn->close();
    }
    public function authenticate($username, $password) {
        // Sử dụng prepared statement để tránh SQL injection
        $stmt = $this->conn->prepare("SELECT * FROM USER WHERE username = ? AND password = ?");
        $stmt->bind_param("ss", $username, $password); // Sử dụng password ở đây là plain text
    
        $stmt->execute();
        $result = $stmt->get_result();
        
        // Kiểm tra nếu tìm thấy người dùng
        if ($result->num_rows > 0) {
            return true; // Đăng nhập thành công
        } else {
            return false; // Đăng nhập thất bại
        }
    }
   
    
}
?>
