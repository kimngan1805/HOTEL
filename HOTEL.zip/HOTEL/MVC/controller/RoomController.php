<?php
require_once "../model/RoomModel.php";

class RoomController {
    private $roomModel;

    public function __construct() {
        $this->roomModel = new RoomModel();
    }

    public function displayRoomDetail($id) {
        // Lấy thông tin phòng từ model
        $roomData = $this->roomModel->getRoomById($id);
        
        if ($roomData) {
            // Chuyển tiếp đến view room-detail
            include "../view/room-detail.php";
        } else {
            echo "Thông tin phòng không khả dụng.";
        }
    }
}
?>
