<?php
require_once "./MVC/model/UserModel.php";

class UserController {
    private $userModel;

    public function __construct() {
        $this->userModel = new UserModel();
    }

    public function register($username, $email, $password, $password_confirm) {
        if ($password !== $password_confirm) {
            echo "Mật khẩu không khớp!";
            return;
        }
    
        if ($this->userModel->register($username, $email, $password, $password_confirm)) {
            echo "Đăng ký thành công!";
        } else {
            echo "Đăng ký thất bại!";
        }
    }
    // public function login($username, $password) {
    //     // Kiểm tra thông tin đăng nhập bằng model
    //     if ($this->userModel->authenticate($username, $password)) {
    //         echo "Đăng nhập thành công!";
    //         header("Location: MVC/view/rooms.php");

    //     } else {
    //         echo "Tên đăng nhập hoặc mật khẩu không đúng!";
    //     }
    // }
    public function login($username, $password) {
        // Kiểm tra thông tin đăng nhập bằng model
        if ($this->userModel->authenticate($username, $password)) {
            // Lưu tên người dùng vào session
            session_start(); // Bắt đầu session
            $_SESSION['username'] = $username; // Lưu tên người dùng vào session
            
            echo "Đăng nhập thành công!";
            header("Location:MVC/view/index.html");
            exit(); // Dừng thực thi code tiếp theo sau khi chuyển hướng
        } else {
            echo "Tên đăng nhập hoặc mật khẩu không đúng!";
        }
       

    }
}
?>
