<?php
session_start();
if (!isset($_SESSION['username'])) {
    echo "Bạn chưa đăng nhập.";
    exit();
}

$username = $_SESSION['username'];
$room_id = $_POST['room_id'];

// Kết nối cơ sở dữ liệu
$conn = new mysqli('localhost', 'root', 'root', 'HOTEL');
if ($conn->connect_error) {
    die("Lỗi kết nối cơ sở dữ liệu: " . $conn->connect_error);
}

// Xóa phòng khỏi bảng favorites
$sql = "DELETE FROM favorites WHERE username = ? AND room_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("si", $username, $room_id);

if ($stmt->execute()) {
    echo "Phòng đã được xóa khỏi danh sách yêu thích.";
} else {
    echo "Lỗi khi xóa phòng: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
