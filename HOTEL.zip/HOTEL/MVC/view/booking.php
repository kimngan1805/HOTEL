<?php
session_start();
// Kiểm tra nếu người dùng đã đăng nhập
if (!isset($_SESSION['username'])) {
    echo "Bạn chưa đăng nhập.";
    exit();
}

$username = $_SESSION['username']; // Lấy tên người dùng từ session

// Kết nối đến cơ sở dữ liệu
$servername = "localhost";
$db_username = "root";
$db_password = "root";
$dbname = "HOTEL";

$conn = new mysqli($servername, $db_username, $db_password, $dbname);

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}

// Truy vấn để lấy email của người dùng
$sql = "SELECT email FROM USER WHERE username = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $username); // Liên kết tên người dùng vào câu lệnh SQL
$stmt->execute();
$stmt->store_result();

// Kiểm tra nếu tìm thấy người dùng và lấy email
if ($stmt->num_rows > 0) {
    $stmt->bind_result($email); // Liên kết kết quả truy vấn với biến $email
    $stmt->fetch(); // Lấy kết quả
} else {
    echo "Không tìm thấy người dùng.";
    exit();
}



// Truy vấn để lấy thông tin người dùng từ cơ sở dữ liệu
$sql = "SELECT username, email, phone FROM USER WHERE username = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $username); // Liên kết tên người dùng vào câu lệnh SQL
$stmt->execute();
$stmt->store_result();

// Kiểm tra nếu tìm thấy người dùng và lấy thông tin
if ($stmt->num_rows > 0) {
    $stmt->bind_result($name, $email, $phone); // Liên kết kết quả truy vấn với các biến
    $stmt->fetch(); // Lấy kết quả
} else {
    echo "Không tìm thấy người dùng.";
    exit();
}


// Giả sử Ngân lấy ngày từ form gửi lên
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $_SESSION['checkin_date'] = $_POST['checkin_date'];
    $_SESSION['checkout_date'] = $_POST['checkout_date'];
    // Chuyển hướng đến step 2 hoặc thực hiện các xử lý tiếp theo
}
// Đóng kết nối
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
        <meta charset="UTF-8">
        <meta name="description" content="Sona Template">
        <meta name="keywords" content="Sona, unica, creative, html">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Sona | Template</title>
        <!-- Google Font -->
        <link href="https://fonts.googleapis.com/css?family=Lora:400,700&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Cabin:400,500,600,700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <!-- Css Styles -->
        <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
        <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
        <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
        <link rel="stylesheet" href="css/flaticon.css" type="text/css">
        <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
        <link rel="stylesheet" href="css/nice-select.css" type="text/css">
        <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
        <link rel="stylesheet" href="css/magnific-popup.css" type="text/css">
        <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
        <link rel="stylesheet" href="css/style.css" type="text/css">
        <link rel="stylesheet" href="css/booking.css" type="text/css">
        <script type="text/javascript" src="http://js.nicedit.com/nicEdit-latest.js"></script>

</head>
<body>

  <div class="booking-steps">
   <div class="step active">
        <div class="circle">
            <span>1</span>
        </div>
                <p> Thông tin khách hàng</p>
    </div>
    <div class="step">
        <div class="circle">
        <span>2</span>
        </div>
        <p>Chi tiết thanh toán</p>
    </div>
    <div class="step">
        <div class="circle">
        <span>3</span>
        </div>
        <p>Xác nhận đặt phòng</p>
    </div>
  </div>
<div class="container" id="step1-container">
        <!-- Left Column -->
    <div class="left-column">
            <!-- Box 1: Greeting -->
            <div class="box greeting">
                <p>Xin chào, <strong><?php echo htmlspecialchars($username); ?></strong>!</p>
                <p>Nếu không phải bạn, <a href="login.php">Thoát</a></p>
            </div>

            <!-- Box 2: Main Guest Information -->
            <div class="box main-guest">
                <h4>Ai là khách chính?</h4>
                <p><strong>Tên:</strong> <?php echo $username; ?></p>
                <p><strong>Email:</strong><?php echo htmlspecialchars($email); ?></p>
                <button class="edit-button">Chỉnh sửa</button>
            </div>

            <!-- Box 3: Special Requests -->
            <!-- Box 3: Special Requests -->
            <div class="box special-requests">
            <form action="process_special_requests.php" method="POST">
                <h4>Yêu cầu đặc biệt</h4>
                <p>Chọn lựa chọn của quý khách. Phụ thuộc vào tình trạng thực tế.</p>
                <div class="inner-box">
                    <p><strong>Quy định hút thuốc (nếu có phòng):</strong></p>
                    <div class="options-row">
                    <div class="options-row">
                        <label>
                            <input type="radio" name="smoking" value="non-smoking">
                            <span class="custom-radio"></span> 
                            <i class="fas fa-smoking-ban"></i> Phòng không hút thuốc
                        </label>
                        <label>
                            <input type="radio" name="smoking" value="smoking">
                            <span class="custom-radio"></span>
                            <i class="fas fa-smoking"></i> Phòng hút thuốc
                        </label>
                    </div>
                    </div>

                    <p><strong>Chọn loại giường (nếu có phòng):</strong></p>
                    <div class="options-row">
                        <label>
                            <input type="radio" name="bed" value="large-bed">
                            <span class="custom-radio"></span>
                            <i class="fas fa-bed"></i> Tôi muốn giường lớn
                        </label>
                        <label>
                            <input type="radio" name="bed" value="two-beds">
                            <span class="custom-radio"></span>
                            <i class="fas fa-procedures"></i> Tôi muốn phòng 2 giường
                        </label>
                    </div>
                </div>
            </form>
                    <!-- Nút thêm yêu cầu đặc biệt -->
            <button class="add-request btn btn-primary" id="add-request-button" onclick="openModal()">
                <i class="fas fa-plus"></i> Thêm yêu cầu đặc biệt
            </button>

            <!-- Chỗ hiển thị yêu cầu đặc biệt -->
            <p id="special-request-display" style="margin-top: 10px;"></p>

            <!-- Modal để nhập yêu cầu đặc biệt -->
            <div id="special-request-modal" class="modal" style="display: none;">
                <div class="modal-content">
                    <span class="close" onclick="closeModal()">&times;</span>
                    <h3>Nhập yêu cầu đặc biệt của bạn</h3>
                    
                    <!-- Khu vực nhập yêu cầu đặc biệt với nicEditor -->
                    <textarea id="special-request-input"></textarea>
                    <br>
                    <button onclick="submitRequest()" class="btn btn-success">OK</button>
                </div>
            </div>
        </div>



            <!-- Box 4: Next Button -->
            <div class="box next-step">
                <button class="next-button" onclick="showStep2()">Kế tiếp</button>
                <p class="confirmation">Xác nhận đặt phòng ngày!</p>
            </div>
    </div>

        <!-- Right Column -->
    <div class="right-column">
        <div class="date-selection-box">
            <div class="date-inputs" id="date-inputs">
                <div class="date-input">
                    <label for="checkin-date">Ngày đến:</label>
                    <input type="date" id="checkin-date" onchange="updateDates()" required>
                </div>
                <div class="date-input">
                    <label for="checkout-date">Ngày đi:</label>
                    <input type="date" id="checkout-date" onchange="updateDates()" required>
                </div>
            </div>
            <!-- Condensed stay summary -->
            <div class="stay-summary" id="stay-summary" style="display: none;">
                <span id="selected-checkin"></span> - <span id="selected-checkout"></span> 
                (<strong id="total-nights"></strong> đêm)
            </div>
</div>


        <?php
        // Kết nối cơ sở dữ liệu
        $servername = "localhost";
        $username = "root";
        $password = "root";
        $dbname = "HOTEL";

        $conn = new mysqli($servername, $username, $password, $dbname);

        // Kiểm tra kết nối
        if ($conn->connect_error) {
            die("Kết nối thất bại: " . $conn->connect_error);
        }

        // Lấy room_id từ URL
        if (isset($_GET['room_id'])) {
            $room_id = $_GET['room_id'];

            // Truy vấn cơ sở dữ liệu để lấy thông tin phòng tương ứng
            $sql = "SELECT * FROM ROOM WHERE ID = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $room_id); // Liên kết room_id vào câu lệnh SQL
            $stmt->execute();
            $result = $stmt->get_result();

            // Hiển thị thông tin phòng
            if ($result->num_rows > 0) {
                $room = $result->fetch_assoc();
                ?>


        <!-- Room Details Section -->
        <div class="room-details-box">
            <div class="room-info">
                <div class="room-image">
                    <img src="<?php echo $room['HINH']; ?>" alt="Hình ảnh phòng">
                </div>
                <div class="room-summary">
                    <p class="room-name">Tên phòng: <?php echo $room['TENPHONG']; ?></p>
                    <p class="price">Giá: <?php echo number_format($room['GIA'], 0, ',', '.'); ?> VND</p>
                    <p class="rating">Sao: <?php echo $room['SAO']; ?></p>
                    
                    <!-- Room Type Display -->
                    <p class="type">
                        <?php
                            if ($room['TYPE'] === 'Single Room') {
                                echo "1x phòng tối đa 1 người ở";
                            } elseif ($room['TYPE'] === 'Double Room') {
                                echo "2x phòng tối đa 2 người ở";
                            }
                        ?>
                    </p>
                </div>
            </div>
        </div>


            <?php
            } else {
                echo "Không tìm thấy phòng này.";
            }

            $stmt->close();
        } else {
            echo "Không có phòng được chọn.";
        }

        $conn->close();
        ?>




        <!-- Step 1: Customer Information -->

            <div class="step-details step1">
                <h3>Bước 1: Thông tin khách hàng</h3>
                <form action="place_order.php" method="POST">
                    <input type="hidden" name="room_id" value="<?php echo $room['ID']; ?>">
                    
                    <!-- Hiển thị tên người dùng -->
                    <label for="name">Tên:</label>
                    <input type="text" name="name" value="<?php echo htmlspecialchars($name); ?>" required><br>
                    
                    <!-- Hiển thị email của người dùng -->
                    <label for="email">Email:</label>
                    <input type="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required><br>
                    
                    <!-- Hiển thị số điện thoại của người dùng -->
                    <label for="phone">Số điện thoại:</label>
                    <input type="tel" name="phone" value="<?php echo htmlspecialchars($phone); ?>" required><br>
                    
                    <!-- Form bên dưới -->
                    <label for="checkin_date">Ngày nhận phòng:</label>
                    <input type="date" name="checkin_date" id="form-checkin-date" required><br>

                    <label for="checkout_date">Ngày trả phòng:</label>
                    <input type="date" name="checkout_date" id="form-checkout-date" required><br>
                </form>
            </div>

        </div>
    
    </div>


<!-- STEP 2 -->


    <div class="step-details step2" style="display: none;">
        <h3>HOÁ ĐƠN ĐIỆN TỬ</h3>
            <div class="invoice-container">
                <!-- Left Column -->
                <div class="invoice-left">
                    <!-- Khung 1: Thông tin khách sạn -->
                    <div class="hotel-info">
                        <p><strong>Hotel</strong></p>
                        <p><strong>Mã số thuế:</strong> 151</p>
                        <p><strong>Số điện thoại:</strong> 09822236</p>
                        <p><strong>Địa chỉ:</strong> Hoà Hải, Đà Nẵng</p>
                        <p><strong>Ngày giờ xuất hóa đơn:</strong> 
                            <?php echo date('d-m-Y H:i:s'); // Lấy ngày giờ hiện tại ?>
                        </p>
                    </div>
                    <?php
                    
                    // Kiểm tra nếu có session ngày nhận và ngày trả phòng
                    $checkin_date = isset($_SESSION['checkin_date']) ? $_SESSION['checkin_date'] : '';
                    $checkout_date = isset($_SESSION['checkout_date']) ? $_SESSION['checkout_date'] : '';
                    ?>

                    <!-- Khung 2: Thông tin khách hàng -->
                    <div class="customer-info">
                        <p><strong>Khách hàng:</strong> <?php echo htmlspecialchars($name); ?></p>
                        <p><strong>Email:</strong> <?php echo htmlspecialchars($email); ?></p>
                        <p><strong>Số điện thoại:</strong> <?php echo htmlspecialchars($phone); ?></p>
                        <p><strong>Phòng:</strong> <?php echo htmlspecialchars($room['TENPHONG']); ?></p>
                        <p><strong>Loại phòng:</strong> <?php echo htmlspecialchars($room['TYPE']); ?></p>
                        <!-- Hiển thị thông tin ngày nhận phòng và ngày trả phòng -->
                        <p><strong>Ngày nhận phòng:</strong> <span id="checkin-display"></span></p>
                        <p><strong>Ngày trả phòng:</strong> <span id="checkout-display"></span></p>
                        <p><strong>Quy định hút thuốc:</strong> 
                        <?php echo isset($_SESSION['smoking']) && $_SESSION['smoking'] === 'non-smoking' ? 'Phòng không hút thuốc' : 'Phòng hút thuốc'; ?>
                        </p>
                        <p><strong>Loại giường:</strong> 
                        <?php echo isset($_SESSION['bed']) && $_SESSION['bed'] === 'large-bed' ? 'Giường lớn' : 'Phòng 2 giường'; ?>
                        <!-- Hiển thị yêu cầu đặc biệt -->
                        <?php if (isset($_SESSION['special_request']) && !empty($_SESSION['special_request'])): ?>
                            <p><strong>Yêu cầu đặc biệt:</strong> <?php echo $_SESSION['special_request']; ?></p>
                        <?php endif; ?>
                        </p>                    
                    </div>
                </div>

                <!-- Right Column -->
                <div class="invoice-right">
                    <!-- Tổng tiền -->
                    <div class="total-amount">
                        <p><strong>Tổng tiền:</strong> <?php echo number_format($room['GIA'], 0, ',', '.'); ?> VND</p>
                    </div>
                    <!-- Nút xác nhận chuyển qua bước 3 -->
                    <div class="confirm-tax-invoice">
                        <button id="confirm-tax-invoice" class="btn">Xác nhận và tiếp tục</button>
                    </div>
                    <div id="tax-invoice-result">
                        <!-- Nếu mã số thuế đúng, sẽ hiển thị tên công ty và mã số thuế -->
                    </div>

                    <!-- Liên kết xuất hóa đơn đỏ -->
                    <div class="tax-invoice-request">
                        <p><small>Nếu bạn muốn xuất hóa đơn đỏ, <a href="#" id="tax-invoice-link">nhấn vào đây</a>.</small></p>
                        </div>
                    </div>
                    

                                        <!-- Modal cho xuất hóa đơn đỏ -->
                                        <!-- Modal cho xuất hóa đơn đỏ -->
                    <div id="tax-invoice-modal" class="modal">
                        <div class="modal-content">
                            <h3>Thông tin hóa đơn đỏ</h3>
                            <form id="tax-invoice-form">
                                <label for="company-name">Tên công ty:</label>
                                <select id="company-name" name="company_name" required>
                                    <option value="">Chọn công ty</option>
                                    <?php
                                    // Lấy danh sách công ty từ cơ sở dữ liệu
                                    $conn = new mysqli("localhost", "root", "root", "HOTEL");
                                    $result = $conn->query("SELECT * FROM companies");

                                    while ($row = $result->fetch_assoc()) {
                                        echo "<option value=\"" . htmlspecialchars($row['company_name']) . "\">" . htmlspecialchars($row['company_name']) . "</option>";
                                    }
                                    ?>
                                </select>

                                <label for="tax-code">Mã số thuế:</label>
                                <input type="text" id="tax-code" name="tax_code" required>

                                <button type="submit">Gửi yêu cầu</button>
                                <button type="button" class="close-modal">Đóng</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
    </div>





            <!-- Bước 3: Xác nhận đặt phòng -->
                        <!-- Bước 3: Xác nhận đặt phòng -->
            <div class="step-details step3" style="display: none;">
                <h3>Bước 3: Xác nhận thanh toán</h3>
                <p>Vui lòng chọn phương thức thanh toán của bạn:</p>
                
                <div class="payment-confirmation-container">
                    <h3>Xác nhận thanh toán</h3>
                    
                    <!-- Nút chọn phương thức thanh toán -->
                    <div id="payment-buttons">
                        <button class="btn-payment" onclick="showBankTransfer()">Chuyển khoản</button>
                        <button class="btn-payment" onclick="showCardPayment()">Thanh toán bằng thẻ</button>
                    </div>

                    <!-- Mã QR cho chuyển khoản -->
                    <div id="qr-section" class="hidden">
                        <h4>Thông tin chuyển khoản</h4>
                        <img src="https://qrcode-gen.com/images/qrcode-default.png" alt="QR Code" class="qr-code">
                        <button class="btn-back" onclick="resetPayment()">Quay lại</button>
                    </div>

                    <!-- Form nhập thông tin thẻ -->
                    <div id="card-section" class="hidden">
                        <h4>Thông tin thẻ</h4>
                        <form>
                            <div class="form-group">
                                <label for="card-number">Số thẻ:</label>
                                <input type="text" id="card-number" required>
                            </div>
                            <div class="form-group">
                                <label for="card-expiry">Ngày hết hạn:</label>
                                <input type="text" id="card-expiry" required>
                            </div>
                            <div class="form-group">
                                <label for="card-cvv">CVV:</label>
                                <input type="text" id="card-cvv" required>
                            </div>
                            <button type="submit" class="btn-submit">Thanh toán</button>
                        </form>
                        <button class="btn-back" onclick="resetPayment()">Quay lại</button>
                    </div>
                </div>

            </div>

           
<br>
<!-- Footer Section Begin -->
<footer class="footer-section">
                <div class="container">
                    <div class="footer-text">
                        <div class="row">
                            <div class="col-lg-4">
                                <div class="ft-about">
                                    <div class="logo">
                                        <a href="#">
                                            <img src="img/footer-logo.png" alt="">
                                        </a>
                                    </div>
                                    <p>We inspire and reach millions of travelers<br /> across 90 local websites</p>
                                    <div class="fa-social">
                                        <a href="#"><i class="fa fa-facebook"></i></a>
                                        <a href="#"><i class="fa fa-twitter"></i></a>
                                        <a href="#"><i class="fa fa-tripadvisor"></i></a>
                                        <a href="#"><i class="fa fa-instagram"></i></a>
                                        <a href="#"><i class="fa fa-youtube-play"></i></a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 offset-lg-1">
                                <div class="ft-contact">
                                    <h6>Contact Us</h6>
                                    <ul>
                                        <li>(12) 345 67890</li>
                                        <li>info.colorlib@gmail.com</li>
                                        <li>856 Cordia Extension Apt. 356, Lake, United State</li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-lg-3 offset-lg-1">
                                <div class="ft-newslatter">
                                    <h6>New latest</h6>
                                    <p>Get the latest updates and offers.</p>
                                    <form action="#" class="fn-form">
                                        <input type="text" placeholder="Email">
                                        <button type="submit"><i class="fa fa-send"></i></button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="copyright-option">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-7">
                                <ul>
                                    <li><a href="#">Contact</a></li>
                                    <li><a href="#">Terms of use</a></li>
                                    <li><a href="#">Privacy</a></li>
                                    <li><a href="#">Environmental Policy</a></li>
                                </ul>
                            </div>
                            <div class="col-lg-5">
                                <div class="co-text"><p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
                <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p></div>
                            </div>
                        </div>
                    </div>
                </div>
            </footer>
            <!-- Footer Section End -->
</body>
<script src="https://cdn.tiny.cloud/1/no-api-key/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
    <script>
        document.querySelectorAll('.next-step').forEach(function(button) {
    button.addEventListener('click', function() {
        // Get the current and next step elements
        let currentStep = button.closest('.step-details');
        let nextStep = currentStep.nextElementSibling;

        // Hide the current step and show the next step
        if (nextStep && nextStep.classList.contains('step-details')) {
            currentStep.style.display = 'none';
            nextStep.style.display = 'block';

            // Update progress bar indicator
            let steps = Array.from(document.querySelectorAll('.booking-steps .step'));
            let currentIndex = steps.findIndex(step => step.classList.contains('active'));

            // Remove 'active' from the current step and add it to the next
            steps[currentIndex].classList.remove('active');
            if (steps[currentIndex + 1]) {
                steps[currentIndex + 1].classList.add('active');
            }
        }
    });
});


        </script>
<script>
function updateDates() {
    // Lấy giá trị ngày đến và ngày đi từ các input
    var checkinDate = document.getElementById("checkin-date").value;
    var checkoutDate = document.getElementById("checkout-date").value;

    // Cập nhật thông tin vào các trường ngày nhận phòng và ngày trả phòng trong form
    document.getElementById("form-checkin-date").value = checkinDate;
    document.getElementById("form-checkout-date").value = checkoutDate;

    // Kiểm tra tính hợp lệ của các ngày
    const today = new Date();
    today.setHours(0, 0, 0, 0); // Đặt giờ, phút, giây, mili giây về 0

    const maxDate = new Date();
    maxDate.setMonth(today.getMonth() + 2); // Giới hạn ngày đi tối đa trong 2 tháng

    const checkin = new Date(checkinDate);
    const checkout = new Date(checkoutDate);

    // Kiểm tra ngày đến không nhỏ hơn hôm nay
    if (checkin < today) {
        alert("Ngày đến không hợp lệ. Vui lòng chọn ngày từ hôm nay trở đi.");
        document.getElementById("checkin-date").value = ""; // Xóa giá trị không hợp lệ
        return;
    }

    // Kiểm tra ngày đi không nhỏ hơn ngày đến
    if (checkout <= checkin) {
        alert("Ngày đi phải sau ngày đến. Vui lòng chọn lại.");
        document.getElementById("checkout-date").value = ""; // Xóa giá trị không hợp lệ
        return;
    }

    // Kiểm tra ngày đi không vượt quá 2 tháng từ hôm nay
    if (checkout > maxDate) {
        alert("Chưa có phòng phù hợp cho ngày bạn chọn. Vui lòng chọn ngày không quá 2 tháng từ hôm nay.");
        document.getElementById("checkout-date").value = ""; // Xóa giá trị không hợp lệ
        return;
    }

    // Cập nhật thông tin ngày lưu trú (stay summary)
    if (checkinDate && checkoutDate) {
        // Tính số đêm
        var timeDiff = checkout.getTime() - checkin.getTime();
        var days = timeDiff / (1000 * 3600 * 24);
        
        // Cập nhật hiển thị ngày đến, ngày đi và số đêm
        document.getElementById("selected-checkin").textContent = checkinDate;
        document.getElementById("selected-checkout").textContent = checkoutDate;
        document.getElementById("total-nights").textContent = days;
        
        // Hiển thị stay summary
        document.getElementById('stay-summary').style.display = 'flex';
        document.getElementById('date-inputs').style.display = 'none';
    
        document.getElementById("stay-summary").style.display = "block";
        
        // Hiển thị ngày nhận phòng và ngày trả phòng dưới
        document.getElementById("checkin-display").textContent = checkinDate;
        document.getElementById("checkout-display").textContent = checkoutDate;
    }
}
</script>


<script type="text/javascript">
        // Khởi tạo nicEditor cho textarea khi mở modal
        function initNicEditor() {
            new nicEditor().panelInstance('special-request-input');
        }
        
        function submitRequest() {
    var specialRequest = nicEditors.findEditor('special-request-input').getContent(); // Lấy nội dung từ nicEditor
    
    if (specialRequest.trim() !== "") {
        // Hiển thị yêu cầu đặc biệt đã nhập
        document.getElementById("special-request-display").innerHTML = "<strong>Yêu cầu đặc biệt:</strong> " + specialRequest;
        
        // Gửi yêu cầu đặc biệt lên server qua AJAX
        var xhr = new XMLHttpRequest();
        xhr.open("POST", "save_special_request.php", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.send("special_request=" + encodeURIComponent(specialRequest));
    }

    closeModal();
}
        
        // Đóng modal
        function closeModal() {
            document.getElementById("special-request-modal").style.display = "none";
            // Xóa nội dung khỏi nicEditor
            nicEditors.findEditor('special-request-input').setContent('');
        }
        
        // Mở modal và khởi tạo nicEditor cho textarea
        function openModal() {
            document.getElementById("special-request-modal").style.display = "block";
            initNicEditor();
        }
    </script>
    <script>
function showStep2() {
   // Ẩn container của bước 1
   document.getElementById('step1-container').style.display = 'none';

   // Hiển thị bước 2
   document.querySelector('.step2').style.display = 'block';

   // Cập nhật thanh tiến trình
   let steps = Array.from(document.querySelectorAll('.booking-steps .step'));
   steps.forEach(step => step.classList.remove('active'));
   steps[1].classList.add('active'); // Bước 2
   document.getElementById("confirm-tax-invoice").addEventListener("click", function() {
    // Ẩn bước 2
    document.querySelector('.step2').style.display = 'none';

    // Hiển thị bước 3
    document.querySelector('.step3').style.display = 'block';

    // Cập nhật thanh tiến trình
    let steps = Array.from(document.querySelectorAll('.booking-steps .step'));
    steps.forEach(step => step.classList.remove('active'));
    steps[2].classList.add('active'); // Bước 3
});

   
}
</script>
<script>
// Hiển thị modal khi nhấn vào "nhấn vào đây"
document.getElementById("tax-invoice-link").addEventListener("click", function(event) {
    event.preventDefault(); // Ngăn chặn hành động mặc định của liên kết
    document.getElementById("tax-invoice-modal").style.display = "flex"; // Hiển thị modal
});

// Đóng modal khi nhấn vào nút "Đóng"
document.querySelector(".close-modal").addEventListener("click", function() {
    document.getElementById("tax-invoice-modal").style.display = "none"; // Ẩn modal
});

// Ngừng gửi form để giữ modal mở hoặc xử lý thêm theo yêu cầu
document.getElementById("tax-invoice-form").addEventListener("submit", function(event) {
    event.preventDefault(); // Ngừng gửi form để xử lý thêm
    alert("Thông tin hóa đơn đỏ đã được gửi!");
    document.getElementById("tax-invoice-modal").style.display = "none"; // Ẩn modal
});
</script>
<script>
// Hiển thị modal khi nhấn vào "nhấn vào đây"
document.getElementById("tax-invoice-link").addEventListener("click", function(event) {
    event.preventDefault();
    document.getElementById("tax-invoice-modal").style.display = "flex";
});

// Đóng modal khi nhấn vào nút "Đóng"
document.querySelector(".close-modal").addEventListener("click", function() {
    document.getElementById("tax-invoice-modal").style.display = "none";
});

// Gửi yêu cầu kiểm tra mã số thuế khi gửi form
document.getElementById("tax-invoice-form").addEventListener("submit", function(event) {
    event.preventDefault();

    // Lấy giá trị từ form
    var companyName = document.getElementById("company-name").value;
    var taxCode = document.getElementById("tax-code").value;

    // Gửi yêu cầu kiểm tra mã số thuế
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "check_tax_code.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.onload = function() {
        if (xhr.status === 200) {
            var response = JSON.parse(xhr.responseText);
            var resultDiv = document.getElementById("tax-invoice-result");

            if (response.success) {
                // Nếu mã số thuế đúng, hiển thị tên công ty và mã số thuế dưới tổng tiền
                var taxInfoHTML = "<p><strong>Tên công ty:</strong> " + response.company_name + "</p>" +
                                  "<p><strong>Mã số thuế:</strong> " + response.tax_code + "</p>";
                resultDiv.innerHTML = taxInfoHTML;
                resultDiv.style.color = "green";
            } else {
                // Nếu mã số thuế không hợp lệ, hiển thị thông báo lỗi
                resultDiv.innerHTML = "<p style='color: red;'>Mã số thuế không hợp lệ!</p>";
            }
        }
    };
    xhr.send("company_name=" + encodeURIComponent(companyName) + "&tax_code=" + encodeURIComponent(taxCode));
});

</script>

<script>
    // Hiển thị mã QR khi chọn chuyển khoản
fun// Hiển thị mã QR khi chọn chuyển khoản
function showBankTransfer() {
    document.getElementById("payment-buttons").style.display = "none";
    document.getElementById("qr-section").style.display = "block";
}

// Hiển thị form nhập thẻ khi chọn thanh toán bằng thẻ
function showCardPayment() {
    document.getElementById("payment-buttons").style.display = "none";
    document.getElementById("card-section").style.display = "block";
}

// Quay lại màn hình chọn phương thức
function resetPayment() {
    document.getElementById("payment-buttons").style.display = "flex";
    document.getElementById("qr-section").style.display = "none";
    document.getElementById("card-section").style.display = "none";
}
</script>



 </html>
