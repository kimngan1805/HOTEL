<!-- all_reviews.php -->

<div class="review-container">
    <?php
    // Kết nối đến cơ sở dữ liệu
    $conn = mysqli_connect("localhost", "root", "root", "HOTEL");

    if (!$conn) {
        die("Kết nối thất bại: " . mysqli_connect_error());
    }

    // Truy vấn dữ liệu từ bảng review
    $sql = "SELECT name, noidung, ngay, sao FROM REVIEW ORDER BY ngay DESC";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $stars = '';
            for ($i = 1; $i <= 5; $i++) {
                $stars .= $i <= $row['sao'] ? '<span class="star">&#9733;</span>' : '<span class="star-empty">&#9734;</span>';
            }

            echo '<div class="review-item">
                <div class="review-left">
                    <h4>' . htmlspecialchars($row['name']) . '</h4>
                    <div class="review-rating">' . $stars . '</div>
                    <p class="review-date">Ngày: ' . date("d/m/Y", strtotime($row['ngay'])) . '</p>
                </div>
                <div class="review-right">
                    <p class="review-text">' . htmlspecialchars($row['noidung']) . '</p>
                </div>
                <div class="clear"></div>
            </div>';
        }
    } else {
        echo "<p>Không có đánh giá nào được tìm thấy.</p>";
    }

    $conn->close();
    ?>
</div>
