<?php
session_start();

// Kết nối trực tiếp đến cơ sở dữ liệu
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "HOTEL";

$conn = new mysqli($servername, $username, $password, $dbname);

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name']; // Lấy tên người dùng
    $rating = $_POST['rating']; // Lấy đánh giá sao
    $review = $_POST['review']; // Lấy nội dung đánh giá

    // Kiểm tra xem người dùng đã đăng nhập chưa (kiểm tra session)
    if (isset($_SESSION['username'])) {
        $name = $_SESSION['username']; // Nếu đã đăng nhập, dùng tên người dùng trong session
    } else {
        echo "Vui lòng đăng nhập để đánh giá.";
        exit();
    }
    // Lấy ngày giờ hiện tại
    $ngay = date('Y-m-d H:i:s'); // Định dạng: YYYY-MM-DD HH:MM:SS

    $stmt = $conn->prepare("INSERT INTO REVIEW (username, sao, noidung, ngay) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("siss", $name, $rating, $review, $ngay); // 's' cho chuỗi, 'i' cho số nguyên, 's' cho ngày

    if ($stmt->execute()) {
       // Đánh giá thành công, chuyển hướng về trang room-detail.php
       header("Location: room-detail.php");
       exit(); // Đảm bảo không thực thi mã phía dưới
    } else {
        echo "Lỗi khi gửi đánh giá: " . $stmt->error;
    }
}
$conn->close(); // Đóng kết nối
?>
