
<?php
session_start(); // Bắt đầu session để truy xuất dữ liệu trong session
?>
<!DOCTYPE html>
<html lang="zxx">

    <head>
        <meta charset="UTF-8">
        <meta name="description" content="Sona Template">
        <meta name="keywords" content="Sona, unica, creative, html">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Sona | Template</title>
        <!-- Google Font -->
        <link href="https://fonts.googleapis.com/css?family=Lora:400,700&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Cabin:400,500,600,700&display=swap" rel="stylesheet">
        <!-- Css Styles -->
        <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
        <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
        <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
        <link rel="stylesheet" href="css/flaticon.css" type="text/css">
        <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
        <link rel="stylesheet" href="css/nice-select.css" type="text/css">
        <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
        <link rel="stylesheet" href="css/magnific-popup.css" type="text/css">
        <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
        <link rel="stylesheet" href="css/style.css" type="text/css">
        <link rel="stylesheet" href="css/demo.css" type="text/css">
    </head>

    <body>
        <!-- Page Preloder -->
        <div id="preloder">
            <div class="loader"></div>
        </div>

        <!-- Offcanvas Menu Section Begin -->
        <div class="offcanvas-menu-overlay"></div>
        <div class="canvas-open">
            <i class="icon_menu"></i>
        </div>
        <div class="offcanvas-menu-wrapper">
            <div class="canvas-close">
                <i class="icon_close"></i>
            </div>
            <div class="search-icon search-switch">
                <i class="icon_search"></i>
            </div>
            <div class="header-configure-area">
                <div class="language-option">
                    <img src="img/flag.jpg" alt="">
                    <span>EN <i class="fa fa-angle-down"></i></span>
                    <div class="flag-dropdown">
                        <ul>
                            <li><a href="#">Zi</a></li>
                            <li><a href="#">Fr</a></li>
                        </ul>
                    </div>
                </div>
                <a href="#" class="bk-btn">Booking Now</a>
            </div>
            <nav class="mainmenu mobile-menu">
                <ul>
                    <li class="active"><a href="./index.html">Home</a></li>
                    <li><a href="./rooms.html">Rooms</a></li>
                    <li><a href="./about-us.html">About Us</a></li>
                    <li><a href="./pages.html">Pages</a>
                        <ul class="dropdown">
                            <li><a href="./room-details.html">Room Details</a></li>
                            <li><a href="./blog-details.html">Blog Details</a></li>
                            <li><a href="#">Family Room</a></li>
                            <li><a href="#">Premium Room</a></li>
                        </ul>
                    </li>
                    <li><a href="./blog.html">News</a></li>
                    <li><a href="./contact.html">Contact</a></li>
                </ul>
            </nav>
            <div id="mobile-menu-wrap"></div>
            <div class="top-social">
                <a href="#"><i class="fa fa-facebook"></i></a>
                <a href="#"><i class="fa fa-twitter"></i></a>
                <a href="#"><i class="fa fa-tripadvisor"></i></a>
                <a href="#"><i class="fa fa-instagram"></i></a>
            </div>
            <ul class="top-widget">
                <li><i class="fa fa-phone"></i> (12) 345 67890</li>
                <li><i class="fa fa-envelope"></i> info.colorlib@gmail.com</li>
            </ul>
        </div>
        <!-- Offcanvas Menu Section End -->

        <!-- Header Section Begin -->
        <header class="header-section header-normal">
            <div class="top-nav">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6">
                            <ul class="tn-left">
                                <li><i class="fa fa-phone"></i> (12) 345 67890</li>
                                <li><i class="fa fa-envelope"></i> info.colorlib@gmail.com</li>
                            </ul>
                        </div>
                        <div class="col-lg-6">
                            <div class="tn-right">
                                <div class="top-social">
                                    <a href="#"><i class="fa fa-facebook"></i></a>
                                    <a href="#"><i class="fa fa-twitter"></i></a>
                                    <a href="#"><i class="fa fa-tripadvisor"></i></a>
                                    <a href="#"><i class="fa fa-instagram"></i></a>
                                </div>
                                <a href="#" class="bk-btn">Booking Now</a>
                                <div class="language-option">
                                    <img src="img/flag.jpg" alt="">
                                    <span>
                                         <?php
                                            // Kiểm tra nếu session chứa tên người dùng
                                                if (isset($_SESSION['username'])) {
                                                    echo "Chào, " . $_SESSION['username'] . "!";
                                                } else {
                                                    echo "Bạn chưa đăng nhập.";
                                                }
                                            ?>
                                    </span>
                                    <div class="flag-dropdown">
                                        <ul>
                                            <li><a href="logout.php">Đăng Xuất</a></li>
                                            <li><a href="#">Trang chủ</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="menu-item">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-2">
                            <div class="logo">
                                <a href="./index.html">
                                    <img src="img/logo.png" alt="">
                                </a>
                            </div>
                        </div>
                        <div class="col-lg-10">
                            <div class="nav-menu">
                                <nav class="mainmenu">
                                    <ul>
                                        <li><a href="./index.html">Home</a></li>
                                        <li class="active"><a href="./rooms.html">Rooms</a></li>
                                        <li><a href="./about-us.html">About Us</a></li>
                                        <li><a href="./pages.html">Pages</a>
                                            <ul class="dropdown">
                                                <li><a href="./room-details.html">Room Details</a></li>
                                                <li><a href="./blog-details.html">Blog Details</a></li>
                                                <li><a href="#">Family Room</a></li>
                                                <li><a href="#">Premium Room</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="./blog.html">News</a></li>
                                        <li><a href="./contact.html">Contact</a></li>
                                    </ul>
                                </nav>
                                <div class="nav-right search-switch">
                                    <i class="icon_search"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- Header End -->
        <!-- Khung tìm kiếm -->
         
       <!-- Khung tìm kiếm -->
    <section class="search-box">
        <form class="search-form" method="GET" action="room-list.php">
            <div class="input-group">
                <label for="hotel-search">
                    <i class="fa fa-search"></i>
                </label>
                <input type="text" id="hotel-search" name="hotel" placeholder="Tìm kiếm phòng hoặc khách sạn" required>
            </div>
            
            <div class="input-group">
                <label for="checkin">
                    <i class="fa fa-calendar"></i>
                </label>
                <input type="date" id="checkin" name="checkin" required>
            </div>
            
            <div class="input-group">
                <label for="checkout">
                    <i class="fa fa-calendar"></i>
                </label>
                <input type="date" id="checkout" name="checkout" required>
            </div>
            
            <div class="input-group">
        <label for="room-type">
            <i class="fa fa-bed"></i>
        </label>
        <select id="room-type" name="room_type" required>
            <option value="single">Single Room</option>
            <option value="double">Double Room</option>
        </select>
    </div>

            <button type="submit" class="search-button">Tìm</button>
        </form>
    </section>    
      <!-- Breadcrumb Section Begin -->
        <div class="breadcrumb-section">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="breadcrumb-text">
                            <h2>Our Rooms</h2>
                            <div class="bt-option">
                                <a href="./home.html">Home</a>
                                <span>Rooms</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Breadcrumb Section End -->

    <!-- Rooms Section Begin -->
    <?php
    
    // Kết nối đến cơ sở dữ liệu
    $conn = mysqli_connect("localhost", "root", "root", "HOTEL");

    // Kiểm tra kết nối
    if (!$conn) {
        die("Kết nối thất bại: " . mysqli_connect_error());
    }

    // Xác định trang hiện tại (mặc định là trang 1)
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $rooms_per_page = 6; // Hiển thị 4 phòng mỗi trang
    $offset = ($page - 1) * $rooms_per_page;

    // Truy vấn tổng số phòng
    $total_rooms_sql = "SELECT COUNT(*) AS total FROM ROOM";
    $total_rooms_result = mysqli_query($conn, $total_rooms_sql);
    $total_rooms_row = mysqli_fetch_assoc($total_rooms_result);
    $total_rooms = $total_rooms_row['total'];

    // Tính tổng số trang
    $total_pages = ceil($total_rooms / $rooms_per_page);

    // Truy vấn danh sách phòng từ bảng 'ROOM' với phân trang
    $sql = "SELECT * FROM ROOM LIMIT $rooms_per_page OFFSET $offset";
    $result = mysqli_query($conn, $sql);

    ?>
    <section class="rooms-section spad">
        <div class="container">
            <div class="row">
                <?php
                // Kiểm tra và hiển thị từng phòng
                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo '<div class="col-lg-4 col-md-6">';
                        echo '<div class="room-item">';
                        echo '<img src="' . $row["HINH"] . '" alt="">';  // 'image' là tên cột chứa tên file ảnh
                        echo '<div class="ri-text">';
                        echo '<h4>' . $row["TENPHONG"] . '</h4>';  // 'name' là tên cột chứa tên phòng
                        echo '<h3>' . $row["GIA"] . '$<span>/Pernight</span></h3>';  // 'price' là giá phòng
                        echo '<table>';
                        echo '<tbody>';
                        echo '<tr><td class="r-o">Size:</td><td>' . $row["SIZE"] . ' ft</td></tr>';
                        echo '<tr><td class="r-o">Capacity:</td><td> ' . $row["TYPE"] . '</td></tr>';
                        echo '<tr><td class="r-o">Bed:</td><td>' . $row["BED"] . '</td></tr>';
                        echo '<tr><td class="r-o">Services:</td><td>' . $row["SERVICE"] . '</td></tr>';
                        echo '</tbody>';
                        echo '</table>';
                        echo '<a href="room-detail.php?id=' . $row["ID"] . '" class="primary-btn">More Details</a>';
                        echo '</div></div></div>';
                    }
                } else {
                    echo "Không có phòng nào được tìm thấy.";
                }

                // Đóng kết nối
                mysqli_close($conn);
                ?>
                <div class="col-lg-12">
            <div class="room-pagination">
                <?php if ($page > 1): ?>
                    <a href="?page=<?php echo $page - 1; ?>">&laquo; Previous</a>
                <?php endif; ?>

                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <a href="?page=<?php echo $i; ?>" <?php if ($i == $page) echo 'class="active"'; ?>><?php echo $i; ?></a>
                <?php endfor; ?>

                <?php if ($page < $total_pages): ?>
                    <a href="?page=<?php echo $page + 1; ?>">Next <i class="fa fa-long-arrow-right"></i></a>
                <?php endif; ?>
        </div>
    </div>
            </div>
        </div>
    </section>
    <!-- Rooms Section End -->


        <!-- Footer Section Begin -->
        <footer class="footer-section">
            <div class="container">
                <div class="footer-text">
                    <div class="row">
                        <div class="col-lg-4">
                            <div class="ft-about">
                                <div class="logo">
                                    <a href="#">
                                        <img src="img/footer-logo.png" alt="">
                                    </a>
                                </div>
                                <p>We inspire and reach millions of travelers<br /> across 90 local websites</p>
                                <div class="fa-social">
                                    <a href="#"><i class="fa fa-facebook"></i></a>
                                    <a href="#"><i class="fa fa-twitter"></i></a>
                                    <a href="#"><i class="fa fa-tripadvisor"></i></a>
                                    <a href="#"><i class="fa fa-instagram"></i></a>
                                    <a href="#"><i class="fa fa-youtube-play"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 offset-lg-1">
                            <div class="ft-contact">
                                <h6>Contact Us</h6>
                                <ul>
                                    <li>(12) 345 67890</li>
                                    <li>info.colorlib@gmail.com</li>
                                    <li>856 Cordia Extension Apt. 356, Lake, United State</li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-3 offset-lg-1">
                            <div class="ft-newslatter">
                                <h6>New latest</h6>
                                <p>Get the latest updates and offers.</p>
                                <form action="#" class="fn-form">
                                    <input type="text" placeholder="Email">
                                    <button type="submit"><i class="fa fa-send"></i></button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="copyright-option">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-7">
                            <ul>
                                <li><a href="#">Contact</a></li>
                                <li><a href="#">Terms of use</a></li>
                                <li><a href="#">Privacy</a></li>
                                <li><a href="#">Environmental Policy</a></li>
                            </ul>
                        </div>
                        <div class="col-lg-5">
                            <div class="co-text"><p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
    Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
    <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p></div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- Footer Section End -->

        <!-- Search model Begin -->
        <div class="search-model">
            <div class="h-100 d-flex align-items-center justify-content-center">
                <div class="search-close-switch"><i class="icon_close"></i></div>
                <form class="search-model-form">
                    <input type="text" id="search-input" placeholder="Search here.....">
                </form>
            </div>
        </div>
        <!-- Search model end -->

        <!-- Js Plugins -->
        <script src="js/jquery-3.3.1.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/jquery.magnific-popup.min.js"></script>
        <script src="js/jquery.nice-select.min.js"></script>
        <script src="js/jquery-ui.min.js"></script>
        <script src="js/jquery.slicknav.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/main.js"></script>
        <script>
                   document.getElementById('hotel-search').addEventListener('input', function() {
    var inputValue = this.value.toLowerCase();
    var suggestionsBox = document.getElementById('suggestions');
    
    // Danh sách các gợi ý có thể
    var suggestions = ['Single Room', 'Family Room', 'Double Room', 'Suite', 'Deluxe Room'];
    var filteredSuggestions = suggestions.filter(function(suggestion) {
        return suggestion.toLowerCase().includes(inputValue); // Lọc theo giá trị nhập vào
    });

    // Hiển thị các gợi ý hoặc ẩn đi nếu không có kết quả
    if (filteredSuggestions.length === 0) {
        suggestionsBox.style.display = 'none'; // Ẩn nếu không có gợi ý
    } else {
        suggestionsBox.style.display = 'block'; // Hiển thị khi có gợi ý
    }

    // Hiển thị các gợi ý
    suggestionsBox.innerHTML = filteredSuggestions.map(function(suggestion) {
        return '<div>' + suggestion + '</div>';
    }).join('');
});

// Thêm sự kiện click vào từng gợi ý
document.getElementById('hotel-search').addEventListener('click', function() {
    var suggestionsBox = document.getElementById('suggestions');
    suggestionsBox.style.display = 'block';
});

// Thêm sự kiện cho gợi ý để tự động điền vào ô tìm kiếm
document.getElementById('suggestions').addEventListener('click', function(e) {
    if (e.target && e.target.nodeName === 'DIV') {
        document.getElementById('hotel-search').value = e.target.innerText;
        document.getElementById('suggestions').style.display = 'none'; // Ẩn gợi ý sau khi chọn
    }
});

            </script>
    </body>

</html>