
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="./MVC/view/css/login.css">
    <title>Đăng nhập - Đăng kí</title>
</head>

<body>

    <div class="container" id="container">
        <div class="form-container sign-up">
            <form action="index.php?action=register" method="POST">
                <h1>Tạo tài khoản</h1>
                <div class="social-icons">
                    <a href="#" class="icon"><i class="fa-brands fa-google-plus-g"></i></a>
                    <a href="#" class="icon"><i class="fa-brands fa-facebook-f"></i></a>
                    <a href="#" class="icon"><i class="fa-brands fa-github"></i></a>
                    <a href="#" class="icon"><i class="fa-brands fa-linkedin-in"></i></a>
                </div>
                <span></span>
                <input type="text" class="form-control" placeholder="Name" id="username" name="username" required>
                <input type="email"  class="form-control"  placeholder="Email" id="email" name="email" required>
                <input type="password"class="form-control"  placeholder="Password" id="pwd" name="password" required>
                <input type="password"class="form-control"  placeholder="Confirm Password" id="pwd2" name="password_confirm" required>
                <button>Đăng kí</button>
            </form>
        </div>
        <div class="form-container sign-in">
            <form action="index.php?action=login" method="POST">
                <h1>Đăng nhập</h1>
                <div class="social-icons">
                    <a href="#" class="icon"><i class="fa-brands fa-google-plus-g"></i></a>
                    <a href="#" class="icon"><i class="fa-brands fa-facebook-f"></i></a>
                    <a href="#" class="icon"><i class="fa-brands fa-github"></i></a>
                    <a href="#" class="icon"><i class="fa-brands fa-linkedin-in"></i></a>
                </div>
                <span></span>
                <input type="text"  class="form-control" placeholder="username" id="username" name="username" required>
                <input type="password" class="form-control" placeholder="Password" id="password" name="password" required>
                <a href="#">Bạn quên mật khẩu?</a>
                <button>Đăng nhập</button>
            </form>
        </div>
        <div class="toggle-container">
            <div class="toggle">
                <div class="toggle-panel toggle-left">
                    <h1>Chào mừng quay trở lại!</h1>
                    <p></p>
                    <button class="hidden" id="login">Đăng nhập</button>
                </div>
                <div class="toggle-panel toggle-right">
                    <h1>Chào bạn!</h1>
                    <p></p>
                    <button class="hidden" id="register">Đăng kí</button>
                </div>
            </div>
        </div>
    </div>

    <script src="./MVC/view/js/script.js"></script>
</body>

</html>