<?php
// Kết nối đến cơ sở dữ liệu
$conn = new mysqli("localhost", "root", "root", "HOTEL");

if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}

$company_name = $_POST['company_name'];
$tax_code = $_POST['tax_code'];

// Truy vấn kiểm tra mã số thuế
$sql = "SELECT company_name, tax_code FROM companies WHERE tax_code = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $tax_code);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    // Nếu tìm thấy mã số thuế hợp lệ, trả về tên công ty và mã số thuế
    $stmt->bind_result($company_name, $tax_code);
    $stmt->fetch();
    echo json_encode(['success' => true, 'company_name' => $company_name, 'tax_code' => $tax_code]);
} else {
    // Nếu không có mã số thuế hợp lệ
    echo json_encode(['success' => false]);
}

$stmt->close();
$conn->close();
?>
