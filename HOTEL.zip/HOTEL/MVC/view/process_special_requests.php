<?php
session_start();

// Kiểm tra nếu request là POST và các lựa chọn đã được gửi
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Lưu các lựa chọn yêu cầu đặc biệt vào session
    $_SESSION['smoking'] = isset($_POST['smoking']) ? $_POST['smoking'] : '';
    $_SESSION['bed'] = isset($_POST['bed']) ? $_POST['bed'] : '';
    $_SESSION['checkin_date'] = $_POST['checkin_date'];
    $_SESSION['checkout_date'] = $_POST['checkout_date'];

    // Chuyển hướng đến step2.php để hiển thị thông tin
    header("Location: step2.php");
    exit();
}
?>
