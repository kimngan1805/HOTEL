<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['special_request'])) {
    // Lưu yêu cầu đặc biệt vào session
    $_SESSION['special_request'] = $_POST['special_request'];
    echo "Yêu cầu đặc biệt đã được lưu.";
} else {
    echo "Lỗi: Không thể lưu yêu cầu đặc biệt.";
}
?>
