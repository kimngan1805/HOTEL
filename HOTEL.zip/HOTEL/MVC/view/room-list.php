<?php
session_start(); // Bắt đầu session

// Lấy dữ liệu từ form và lưu vào session
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (isset($_GET['checkin'], $_GET['checkout'])) {
        $_SESSION['checkin'] = $_GET['checkin'];
        $_SESSION['checkout'] = $_GET['checkout'];
    }
}

// Kết nối đến cơ sở dữ liệu
$conn = mysqli_connect("localhost", "root", "root", "HOTEL");

// Kiểm tra kết nối
if (!$conn) {
    die("Kết nối thất bại: " . mysqli_connect_error());
}

// Xác định trang hiện tại (mặc định là trang 1)
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$rooms_per_page = 6; // Hiển thị 6 phòng mỗi trang
$offset = ($page - 1) * $rooms_per_page;

// Lấy thông tin tìm kiếm từ form
$search_query = isset($_GET['hotel']) ? mysqli_real_escape_string($conn, $_GET['hotel']) : '';
$room_type = isset($_GET['room_type']) ? mysqli_real_escape_string($conn, $_GET['room_type']) : '';

// Truy vấn tổng số phòng phù hợp với tiêu chí tìm kiếm
$total_rooms_sql = "SELECT COUNT(*) AS total FROM ROOM WHERE TENPHONG LIKE '%$search_query%'";
if ($room_type) {
    $total_rooms_sql .= " AND TYPE = '$room_type'";
}
$total_rooms_result = mysqli_query($conn, $total_rooms_sql);
$total_rooms_row = mysqli_fetch_assoc($total_rooms_result);
$total_rooms = $total_rooms_row['total'];

// Tính tổng số trang
$total_pages = ceil($total_rooms / $rooms_per_page);

// Truy vấn danh sách phòng với phân trang và điều kiện tìm kiếm
$sql = "SELECT * FROM ROOM WHERE TENPHONG LIKE '%$search_query%'";
if ($room_type) {
    $sql .= " AND TYPE = '$room_type'";
}
$sql .= " LIMIT $rooms_per_page OFFSET $offset";
$result = mysqli_query($conn, $sql);

?>

<section class="rooms-section spad">
    <div class="container">
        <div class="row">
            <?php
            // Kiểm tra và hiển thị từng phòng
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo '<div class="col-lg-4 col-md-6">';
                    echo '<div class="room-item">';
                    echo '<img src="' . $row["HINH"] . '" alt="">';  // 'HINH' là tên cột chứa file ảnh
                    echo '<div class="ri-text">';
                    echo '<h4>' . $row["TENPHONG"] . '</h4>';  // 'TENPHONG' là tên cột chứa tên phòng
                    echo '<h3>' . $row["GIA"] . '$<span>/Pernight</span></h3>';  // 'GIA' là giá phòng
                    echo '<table>';
                    echo '<tbody>';
                    echo '<tr><td class="r-o">Size:</td><td>' . $row["SIZE"] . ' ft</td></tr>';
                    echo '<tr><td class="r-o">Capacity:</td><td> ' . $row["TYPE"] . '</td></tr>';
                    echo '<tr><td class="r-o">Bed:</td><td>' . $row["BED"] . '</td></tr>';
                    echo '<tr><td class="r-o">Services:</td><td>' . $row["SERVICE"] . '</td></tr>';
                    echo '</tbody>';
                    echo '</table>';
                    echo '<a href="room-detail.php?id=' . $row["ID"] . '" class="primary-btn">More Details</a>';
                    echo '</div></div></div>';
                }
            } else {
                echo "Không có phòng nào được tìm thấy.";
            }
            ?>
        </div>

        <!-- Phân trang -->
        <div class="col-lg-12">
            <div class="room-pagination">
                <?php if ($page > 1): ?>
                    <a href="?page=<?php echo $page - 1; ?>">&laquo; Previous</a>
                <?php endif; ?>

                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <a href="?page=<?php echo $i; ?>" <?php if ($i == $page) echo 'class="active"'; ?>><?php echo $i; ?></a>
                <?php endfor; ?>

                <?php if ($page < $total_pages): ?>
                    <a href="?page=<?php echo $page + 1; ?>">Next <i class="fa fa-long-arrow-right"></i></a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<?php
// Đóng kết nối
mysqli_close($conn);
?>
