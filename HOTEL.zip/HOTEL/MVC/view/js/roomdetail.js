// Mở lightbox khi nhấn vào hình ảnh
document.addEventListener('DOMContentLoaded', function () {
    var images = document.querySelectorAll('.clickable-image');
    var lightbox = document.createElement('div');
    lightbox.classList.add('lightbox');
    document.body.appendChild(lightbox);

    images.forEach(function (image) {
        image.addEventListener('click', function () {
            lightbox.style.display = 'block';
            var img = document.createElement('img');
            img.src = image.src;
            var content = document.createElement('div');
            content.classList.add('lightbox-content');
            content.appendChild(img);
            lightbox.innerHTML = '';
            lightbox.appendChild(content);

            var closeBtn = document.createElement('span');
            closeBtn.classList.add('lightbox-close');
            closeBtn.innerHTML = '&times;';
            content.appendChild(closeBtn);

            closeBtn.addEventListener('click', function () {
                lightbox.style.display = 'none';
            });
        });
    });
});
